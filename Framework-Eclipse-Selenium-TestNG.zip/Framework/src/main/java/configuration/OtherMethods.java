package configuration;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;

public class OtherMethods {
	private Configuration config = new Configuration();
	
	/**
	 * Add here more java methods in this class if its needed.
	 * If you want to turn on the messages in the methods you need to set the value to 'on' of the 'messages' variable from the 'configuration.Configuration' class.
	 */

    /** 
     * This method is used to assign the copied value (value from the clip board) to a variable.
     * 
     * @return 				- data from the click board will be returned.
     */
    public String clickboardData() throws UnsupportedFlavorException, IOException {
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
        String className = this.getClass().getSimpleName(); // Get the name of the class.
        try {
            // Get data from the click board.
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Clipboard clipboard = toolkit.getSystemClipboard();
            String clickboardData = (String) clipboard.getData(DataFlavor.stringFlavor);
            if (clickboardData != null) {
            	messagesMetohd("Message: Using the click board data. The data is : " + clickboardData);
            } else {
                System.out.println("ERROR! It seems that the click board is empty.");
            }
            return clickboardData;
        } catch (Exception e) {
            System.out.println("ERROR! The operadion was not compleate. Please review the '" + methodName +
                "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
        }
        return null;
    }

    /**
     * This method is used for generation random strings with only numbers. The max size of the string should be 10 symbols.
     * 
     * @param stringCharacters			- provide the characters that will be used for random generation.
     * @return							- the random generated string will be returned.
     */
    public String randomString(String stringCharacters) {
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
        String className = this.getClass().getSimpleName(); // Get the name of the class.
        try {
            SecureRandom secureRandom = new SecureRandom();
            int len = 10;
            StringBuilder sb = new StringBuilder(len);
            for (int i = 0; i < len; i++)
                sb.append(stringCharacters.charAt(secureRandom.nextInt(stringCharacters.length())));
        	messagesMetohd("Message: Random string is generated '"+sb.toString()+"'. The string was created by using the following characted '"+stringCharacters+"'.");
            return sb.toString();
        } catch (Exception e) {
            System.out.println("ERROR! The operadion was not compleate. Please review the '" + methodName +
                "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
        }
        return null;
    }

    /**
     * This method is used to generate unique random numbers.
     * 
     * @param maxNumber				- provide a maximum number for randomly generating range. The range begin form 0.
     * @param randomUniqueNumber	- provide how many unique random numbers should be created. The value should be equal or less than 'maxNumber' value. The first value starts from 0.
     * @return						- the randomly generated integer will be returned.
     */
    public ArrayList < Integer > uniqueRandomNumber(int maxNumber, int randomUniqueNumbers) {
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
        String className = this.getClass().getSimpleName(); // Get the name of the class.
        try {
            // Generate unique random number.
            ArrayList < Integer > numbers = new ArrayList < Integer > (); // Define ArrayList to hold Integer objects
            ArrayList < Integer > finalResult = new ArrayList < Integer > (); // Define ArrayList to hold the unique generated integers.
            for (int i = 0; i <= maxNumber; i++) {
                numbers.add(i);
            }
            Collections.shuffle(numbers);
            for (int j = 0; j <= randomUniqueNumbers; j++) {
                finalResult.add(numbers.get(j)); // Add the collection to the array.
            }
        	messagesMetohd("Message: Random integers is generated '"+finalResult+"'.");
            return finalResult;
        } catch (Exception e) {
            System.out.println("ERROR! The operadion was not compleate. Please review the '" + methodName +
                "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
        }
        return null;
    }

    /**
     * This method is used to generate random unique number (the number is based on current Unix time).
     * 
     * @return				- the current unix time will be returned.
     */
    public long unixTime() {
        long unixTime = 0;
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
        String className = this.getClass().getSimpleName(); // Get the name of the class.
        try {
            unixTime = Instant.now().getEpochSecond(); // Generate Unix time.
        	messagesMetohd("Message: The current unix time is: "+unixTime+".");
            return unixTime; // Return the Unix time value.
        } catch (Exception e) {
            System.out.println("ERROR! The operadion was not compleate. Please review the '" + methodName +
                "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
        }
        if (unixTime == 0)
        {
        	 System.out.println("It seems that we have an issue during the execution of the method '"+ methodName + "' from class '" + className); // This message will be shown if something is gone wrong with the method.
        }
        return unixTime;
    }

    
    /**
     * Get the method name for a depth in call stack.
     * 
     * @param depth		- depth in the call stack (0 means current method, 1 means called method, etc...).
     * @return 			- the method name will be returned.
     */
    public String getCallerMethodName(int depth) {
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
        String className = this.getClass().getSimpleName(); // Get the name of the class.
        try {
        	messagesMetohd("Message: The called method name is: "+StackWalker.getInstance().walk(s -> s.skip(depth).findFirst()).get().getMethodName()+".");
  		    return StackWalker.getInstance().walk(s -> s.skip(depth).findFirst()).get().getMethodName();	
        } catch (Exception e) {
            System.out.println("ERROR! The operadion was not compleate. Please review the '" + methodName +
                "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
        }
		return null;
    }
    
    /**
     * Get the class name for a depth in call stack.
     * 
     * @param depth		- depth in the call stack (0 means current method, 1 means called method, etc...).
     * @return 			- the class name will be returned.
     */
    public String getCallerClassName(int depth) {
    	String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    	String className = this.getClass().getSimpleName(); // Get the name of the class.
    	try {
        	messagesMetohd("Message: The called class name is: "+StackWalker.getInstance().walk(s -> s.skip(depth).findFirst()).get().getClassName()+".");
  		    return StackWalker.getInstance().walk(s -> s.skip(depth).findFirst()).get().getClassName();
    	} catch (Exception e) {
            System.out.println("ERROR! The operadion was not compleate. Please review the '" + methodName +
                "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
        }
		return null;
    }
    
    /**
     * The method is used to turn of and on messages.
     * 
     * @param message				- provide the message.
     */
    public void messagesMetohd(String message) {
    	String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    	String className = this.getClass().getSimpleName(); // Get the name of the class.
    	try {
    		if(config.messages == "on") {
    			System.out.print(message);    			
    		}
    		else if (config.messages == "off") {
    			// The messages is turned off.
    		}
    		else {
    			System.out.print("It seems that the 'messages' variable from the 'configuration.Configuration' class is using wrong value. Please review this variable."); 
    		}
    	} catch (Exception e) {
            System.out.println("ERROR! The operadion was not compleate. Please review the '" + methodName +
                "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
        }
		
    }
}