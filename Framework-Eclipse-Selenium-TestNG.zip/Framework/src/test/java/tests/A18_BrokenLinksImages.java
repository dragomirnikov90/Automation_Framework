package tests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class A18_BrokenLinksImages {

	private WebDriver driver; // Declare a WebDriver.
	private String baseURL;
	public static String status = "passed"; // this is used into the CheckAllImagesFromThePageForBrokenImages annotation

	// Check if the element is displayed.
	@Test
	public void checkElementIsDisplayed() {
		WebElement image = driver
				.findElement(By.xpath("(//*[contains(text(),'Valid image')]/following-sibling::img)[1]"));
		if (image.isDisplayed()) {
			System.out.println("The element is displayed");
		} else {
			System.out.println("The element is NOT displayed");
		}
	}

	// Check if the element getSize height and width are != 0.
	@Test
	public void checkElementSize() {
		WebElement image = driver
				.findElement(By.xpath("(//*[contains(text(),'Valid image')]/following-sibling::img)[2]"));
		Dimension imageSize = image.getSize();
		System.out.println(imageSize);
		if (imageSize.height != 0 && imageSize.width != 0) {
			System.out.println("The element is displayed");
		} else {
			System.out.println("The element is NOT displayed");
		}
	}

	// Check all images form the page - for broken images.
	@Test
	public void checkAllImagesFromThePageForBrokenImages() {
		Integer brokenImageCounter = 0;
		try {
			brokenImageCounter = 0;
			List<WebElement> image_list = driver.findElements(By.tagName("img"));
			// Print the total number of images on the page
			System.out.println("The page contains " + image_list.size() + " images");
			for (WebElement img : image_list) {
				if (img != null) {
					if (img.getAttribute("naturalWidth").equals("0")) {
						System.out.println(img.getAttribute("outerHTML") + " is broken.");
						brokenImageCounter++;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			status = "failed";
			System.out.println(e.getMessage());
		}
		status = "passed";
		System.out.println("The page " + baseURL + "broken" + " has " + brokenImageCounter + " broken images");
	}
	

	// Check if the link is 'broken'.
	@Test
	public void checkIfLinkIsBroken() {
		WebElement brokenLink = driver
				.findElement(By.xpath("//*[contains(text(),'Click Here for Broken Link')]"));
		brokenLink.click();
		try {
			WebElement errorPage = driver.findElement(By.xpath("//div[@class='example']/p"));
			String actualErrorMessage = errorPage.getText();
			String expectedErrorMessage = "This page returned a 500 status code.";
			if (expectedErrorMessage.contains(actualErrorMessage)) {
				System.out.println("The hyperlink is valid ");
			} else {
				System.out.println("The hyperlink is NOT VALID.");
			}
		} catch (Exception e) {

		}
	}
	
	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver(); // Create a new instance of Chrome driver.
		baseURL = "https://demoqa.com/"; // Declare a base URL value.
		driver.manage().window().maximize(); // Set opened browser to 100% width and 100% high.
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS); // Set Implicit Wait.
		driver.get(baseURL + "broken"); // Navigate to base URL + page.
	}

	@AfterClass
	public void afterClass() {
	driver.quit();
	}
}
